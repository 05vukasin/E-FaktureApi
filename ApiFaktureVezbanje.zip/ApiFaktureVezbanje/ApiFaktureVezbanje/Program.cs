﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace ApiFaktureVezbanje
{
    internal class Program
    {
        static async Task Main(string[] args)
        {

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Izaberi broj opcije:");
            Console.WriteLine();
            Console.WriteLine("1: Pretrazi sve kompanije");
            Console.WriteLine("2: Preuzmi sve kompanije (sacuvaj fajl na svom racunaru)");
            Console.WriteLine("3: Preuzmi jedinice mere (POTREBAN API KLJUC)");
            Console.WriteLine("4: Objavljivanje fakture na e-fakture (POTREBAN API KLJUC)");
            Console.WriteLine("5: Slanje Invoice Ubl fakture (POTREBAN API KLJUC)");
            Console.WriteLine("6: Informacije o odredjenoj fakturi (POTREBAN API KLJUC)");
            Console.WriteLine("7: Obrisi odredjenu fakturu (POTREBAN API KLJUC)");
            Console.WriteLine("8: Potpis odredjene fakture (POTREBAN API KLJUC)");
            Console.WriteLine("9: Otkazi odredjenu fakturu (POTREBAN API KLJUC)");
            Console.WriteLine("10: Storno fakturisanje (POTREBAN API KLJUC)");
            Console.WriteLine("11: Preuzmi nabavnu fakturu (POTREBAN API KLJUC)");
            Console.WriteLine("12: Preuzmi XML prodajne fakture (POTREBAN API KLJUC)");
            Console.WriteLine("13: Pogledaj status odredjene fakture (POTREBAN API KLJUC)");
            Console.WriteLine("14: Dobij listu razloga za izuzeće od PDV-a (POTREBAN API KLJUC)");
            Console.WriteLine("15: Dobij ID-ove faktura na osnovu statusa i datuma (POTREBAN API KLJUC)");
            Console.WriteLine("16: Obriši draft ili novu fakturu (POTREBAN API KLJUC)");
            Console.WriteLine("17: Dobij ID-ove nabavnih faktura na osnovu statusa i datuma(POTREBAN API KLJUC)");
            Console.WriteLine("18: Preuzimanje nabavne fakture kao XML (POTREBAN API KLJUC)");
            Console.WriteLine("19: Prihvatanje/Odbijanje Nabavne Fakture (POTREBAN API KLJUC)");
            Console.WriteLine("20: Potpis odredjene nabavne fakture (POTREBAN API KLJUC)");
            Console.WriteLine("21: Dobij ID-ove nabavnih faktura na osnovu statusa i datuma(POTREBAN API KLJUC)");
            Console.WriteLine("22: Pretplati se na obaveštenja o promenama statusa faktura (POTREBAN API KLJUC)");
            Console.WriteLine("23: Evidentiraj PDV za nabavnu fakturu sa obrnutim porezom (POTREBAN API KLJUC)");
            Console.WriteLine("24: Evidentiraj grupni PDV sa mogućnošću korekcije (POTREBAN API KLJUC)");
            Console.WriteLine("25: Dobij evidencije grupnog PDV-a po datumima (POTREBAN API KLJUC)");
            Console.WriteLine("26: Otkazivanje svih verzija grupne evidencije PDV-a(POTREBAN API KLJUC)");
            Console.WriteLine("27: Dobij grupnu evidenciju PDV-a po ID-u (POTREBAN API KLJUC)");
            Console.WriteLine("28: Evidentiraj individualni PDV (POTREBAN API KLJUC)");
            Console.WriteLine("29: Dobij individualne PDV zapise (POTREBAN API KLJUC)");
            Console.WriteLine("30: Otkaži individualnu PDV evidenciju (POTREBAN API KLJUC)");
            Console.WriteLine("31: Dobij individualnu PDV evidenciju (POTREBAN API KLJUC)");
            Console.WriteLine("32: Dobij detalje fiskalnog računa (POTREBAN API KLJUC)");
            Console.WriteLine("33: Dobij detalje fiskalnog računa za nabavku (POTREBAN API KLJUC)");
            Console.WriteLine("34: Pretraži fakture po promeni statusa (POTREBAN API KLJUC)");
            Console.WriteLine("35: Preuzmi XML fakturu javne nabavke (POTREBAN API KLJUC)");
            Console.WriteLine("36: Preuzmi fakturu za javnu nabavku (POTREBAN API KLJUC)");
            Console.WriteLine("37: Preuzmi potpis fakture za javnu nabavku (POTREBAN API KLJUC)");
            Console.WriteLine("38: Preuzimanje ID-ova fakture za javnu nabavku (POTREBAN API KLJUC)");
            Console.WriteLine("39: Preuzimanje tiketa za CIR fakture (POTREBAN API KLJUC)");
            Console.WriteLine("40: Pretraga CIR tiketa (POTREBAN API KLJUC)");
            Console.WriteLine("41: Kreiranje CIR tiketa (POTREBAN API KLJUC)");
            Console.WriteLine("42: Pribavljanje istorije CIR tiketa (POTREBAN API KLJUC)");
            Console.WriteLine("43: Pribavljanje istorije dodeljivanja prodajnih faktura (POTREBAN API KLJUC)");
            Console.WriteLine("44: Pribavljanje informacija o uplatama i istoriji uplata za prodajne fakture (POTREBAN API KLJUC)");
            Console.WriteLine("45: Preuzimanje fakture kao FileStream (POTREBAN API KLJUC)");
            Console.WriteLine("46: Dodeljivanje CIR fakture (POTREBAN API KLJUC)");
            Console.WriteLine("47: Otkazivanje dodele CIR fakture (POTREBAN API KLJUC)");
            Console.WriteLine("48: Prihvatanje ili odbijanje CIR fakture (POTREBAN API KLJUC)");
            Console.WriteLine("49: Dobijanje istorije dodeljivanja kupovne fakture (POTREBAN API KLJUC)");
            Console.WriteLine("50: Dobijanje detaljnih informacija o plaćanjima i istoriji transakcija za odabranu CIR fakturu (POTREBAN API KLJUC)");
            Console.WriteLine("51: Azuriranje informacija o kompaniji na e-fakturama (POTREBAN API KLJUC)");
            Console.WriteLine("52: Proveri da li kompanija ima aktivan nalog na e-fakturama");


            string choice = Console.ReadLine();

            Console.Clear();

            switch (choice)
            {
                case "1":                   
                    await PretragaKompanije();
                    break;
                case "2":
                    await PreuzmiSveKompanije();
                    break;
                case"3": 
                    await UzmiJediniceMere();
                    break;
                case "4":
                    await ObjaviFakturu();
                    break;
                case "5":
                    await SendUblInvoice();
                    break;
                case "6":
                    await FakturaInfo();
                    break;
                case "7":
                    await FakturaBrisanje();
                    break;
                case "8":
                    await FakturaPotpis();
                    break;
                case "9":
                    await FakturaOtkazivanje();
                    break;
                case "10":
                    await FakturaStorno();
                    break;
                case "11":
                    await NabavnaFakturaPreuzimanje();
                    break;
                case "12":
                    await FakturaProdajnaXml();
                    break;
                case "13":
                    await PregledStatusaFakture();
                    break;
                case "14":
                    await ListaRazlogaPdvIzuzece();
                    break;
                case "15":
                    await FakturaPoStatusuIDatumu();
                    break;
                case "16":
                    await FakturaDraftBrisanje();
                    break;
                case "17":
                    await FakturaNabavnaPoStatusuIDatumu();
                    break;
                case "18":
                    await FakturaNabavnaXml();
                    break;
                case "19":
                    await FakturaNabavnaPrihvatiOdbi();
                    break;
                case "20":
                    await FakturaNabavnaPotpis();
                    break;
                case "21":
                    await FakturaNabavnaIdPoStatusuIDatumu();
                    break;
                case "22":
                    await SubscribeToInvoiceStatusChanges();
                    break;
                case "23":
                    await RecordVATReverseCharge();
                    break;
                case "24":
                    await RecordGroupVATWithCorrection();
                    break;
                case "25":
                    await FetchGroupVATRecords();
                    break;
                case "26":
                    await CancelGroupVatRecordings();
                    break;
                case "27":
                    await GetGroupVatRecordById();
                    break;
                case "28":
                    await RecordIndividualVAT();
                    break;
                case "29":
                    await GetIndividualVATRecords();
                    break;
                case "30":
                    await CancelIndividualVATRecord();
                    break;
                case "31":
                    await GetIndividualVATRecord();
                    break;
                case "32":
                    await GetFiscalBillDetails();
                    break;
                case "33":
                    await GetFiscalBillForPurchase();
                    break;
                case "34":
                    await SearchInvoicesByStatusChange();
                    break;
                case "35":
                    await DownloadPublicPurchaseInvoiceXML();
                    break;
                case "36":
                    await DownloadPublicPurchaseInvoice(); ;
                    break;
                case "37":
                    await DownloadPublicPurchaseInvoiceSignature();
                    break;
                case "38":
                    await FetchInvoiceIDs();
                    break;
                case "39":
                    await FetchCIRTickets();
                    break;
                case "40":
                    await FindCIRTickets();
                    break;
                case "41":
                    await CreateCIRTicket();
                    break;
                case "42":
                    await GetCirTicketHistory();
                    break;
                case "43":
                    await GetSalesInvoiceAssignmentHistory();
                    break;
                case "44":
                    await GetInvoicePaymentsAndHistory();
                    break;
                case "45":
                    await DownloadInvoiceAsFileStream();
                    break;
                case "46":
                    await AssignCirInvoice();
                    break;
                case "47":
                    await CancelAssignCirInvoice();
                    break;
                case "48":
                    await AcceptRejectCirInvoice();
                    break;
                case "49":
                    await GetPurchaseInvoiceAssignmentHistory();
                    break;
                case "50":
                    await GetInvoicePaymentsAndHistoryByCIRId();
                    break;
                case "51":
                    await UpdateCompany();
                    break;
                case "52":
                    await CheckIfCompanyRegisteredOnEFaktura();
                    break;

                default:
                    Console.WriteLine("Nepoznata opcija.");
                    break;
            }
            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Unesite '1' da ponovo pokrenete program, ili bilo koji drugi taster za izlaz.");
            if (Console.ReadLine() == "1")
            {
                Console.Clear();
                Main(args); // Rekurzivno pozivanje Main funkcije za restart
            }

            Console.WriteLine("Pritisni bilo koje dugme za izlaz...");
            Console.ReadKey(); // Keep the console window open

        }

        public static async Task PretragaKompanije()
        {
            string baseUrl = "https://efaktura.mfin.gov.rs/api/publicApi/getAllCompanies"; // Adjust the URL if needed
            Console.Write("Upisi ime kompanije koju trazis: ");
            string searchQuery = Console.ReadLine().ToLower(); // Read the user input and convert to lower case for case insensitive comparison

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    HttpResponseMessage response = await client.GetAsync(baseUrl + "?includeAllStatuses=false");
                    if (response.IsSuccessStatusCode)
                    {
                        string jsonData = await response.Content.ReadAsStringAsync();
                        List<Company> companies = JsonConvert.DeserializeObject<List<Company>>(jsonData);
                        List<Company> filteredCompanies = companies.FindAll(c => c.Name.ToLower().Contains(searchQuery));

                        if (filteredCompanies.Count > 0)
                        {
                            foreach (var company in filteredCompanies)
                            {
                                Console.WriteLine($"Naziv: {company.Name}, Registracioni Kod: {company.RegistrationCode}");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Nema pronadjenih kompanija sa tim imenom.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error: " + response.StatusCode);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }

           
        }


        public static async Task PreuzmiSveKompanije()
        {
            string baseUrl = "https://efaktura.mfin.gov.rs/api/publicApi/downloadAllCompanies?includeAllStatuses=false";
            // Automatically find the Downloads folder of the current user
            string downloadsPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + @"\Downloads";
            string localFilePath = Path.Combine(downloadsPath, "companies.csv");

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        using (var stream = await response.Content.ReadAsStreamAsync())
                        {
                            using (var fileStream = new FileStream(localFilePath, FileMode.Create, FileAccess.Write, FileShare.None))
                            {
                                await stream.CopyToAsync(fileStream);
                                fileStream.Close();
                            }
                        }
                        Console.WriteLine("Uspesno preuzimanje, sacuvano na: " + localFilePath);
                    }
                    else
                    {
                        Console.WriteLine("Error: " + response.StatusCode);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occurred: " + ex.Message);
            }
        
        }
        public class Company
        {
            public string BudgetCompanyNumber { get; set; }
            public string RegistrationCode { get; set; }
            public string VatRegistrationCode { get; set; }
            public string Name { get; set; }
            public string RegistrationDate { get; set; }
        }


        public static async Task UzmiJediniceMere()
        {
            Console.Write("Unesi API kljuc: ");
            string apiKey = Console.ReadLine(); // User inputs their API key

            string baseUrl = "https://efaktura.mfin.gov.rs/api/publicApi/get-unit-measures";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey); // Set the API key in the header

                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        string jsonData = await response.Content.ReadAsStringAsync();
                        List<UnitMeasure> unitMeasures = JsonConvert.DeserializeObject<List<UnitMeasure>>(jsonData);

                        foreach (var unitMeasure in unitMeasures)
                        {
                            Console.WriteLine($"ID: {unitMeasure.Id}, Name: {unitMeasure.Name}");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error: " + response.StatusCode);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occurred: " + ex.Message);
            }
        }

        public class UnitMeasure
        {
            public int Id { get; set; }
            public string Name { get; set; }
        }

        public static async Task ObjaviFakturu()
        {
            Console.Write("Unesi API kljuc: ");
            string apiKey = Console.ReadLine();
            Console.Write("Unesi putanju do UBL fajla: ");
            string filePath = Console.ReadLine();
            Console.Write("Unesi Request ID: ");
            string requestId = Console.ReadLine();
            Console.Write("Posalji u CIR (Yes/No): ");
            string sendToCir = Console.ReadLine();
            Console.Write("Izvrsi validaciju (true/false): ");
            string executeValidation = Console.ReadLine();

            string baseUrl = "https://efaktura.mfin.gov.rs/api/publicApi/sales-invoice/ubl/upload";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    using (var content = new MultipartFormDataContent())
                    {
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);
                        content.Add(new StringContent(requestId), "requestId");
                        content.Add(new StringContent(sendToCir), "sendToCir");
                        content.Add(new StringContent(executeValidation), "executeValidation");

                        if (File.Exists(filePath))
                        {
                            var fileContent = new ByteArrayContent(File.ReadAllBytes(filePath));
                            fileContent.Headers.ContentType = MediaTypeHeaderValue.Parse("application/xml");
                            content.Add(fileContent, "ubiFile", Path.GetFileName(filePath));

                            HttpResponseMessage response = await client.PostAsync(baseUrl, content);
                            if (response.IsSuccessStatusCode)
                            {
                                Console.WriteLine("UBL file uploaded successfully!");
                            }
                            else
                            {
                                Console.WriteLine("Error: " + response.StatusCode);
                            }
                        }
                        else
                        {
                            Console.WriteLine("File not found: " + filePath);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occurred: " + ex.Message);
            }
        }


        public static async Task SendUblInvoice()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite putanju do UBL fajla: ");
            string filePath = Console.ReadLine();

            Console.Write("Unesite identifikator zahteva: ");
            string requestId = Console.ReadLine();

            Console.Write("Da li želite poslati u CIR (Yes/No): ");
            string sendToCir = Console.ReadLine();

            Console.Write("Da li želite izvršiti validaciju (true/false): ");
            string executeValidation = Console.ReadLine();

            string baseUrl = "https://efaktura.mfin.gov.rs/api/publicApi/sales-invoice/ubl";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    using (var content = new MultipartFormDataContent())
                    {
                        content.Add(new StringContent(requestId), "requestId");
                        content.Add(new StringContent(sendToCir), "sendToCir");
                        content.Add(new StringContent(executeValidation), "executeValidation");

                        if (File.Exists(filePath))
                        {
                            var fileContent = new ByteArrayContent(File.ReadAllBytes(filePath));
                            fileContent.Headers.ContentType = MediaTypeHeaderValue.Parse("application/xml");
                            content.Add(fileContent, "ubiFile", Path.GetFileName(filePath));

                            HttpResponseMessage response = await client.PostAsync(baseUrl, content);
                            if (response.IsSuccessStatusCode)
                            {
                                Console.WriteLine("Faktura je uspešno poslata!");
                            }
                            else
                            {
                                Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                            }
                        }
                        else
                        {
                            Console.WriteLine("Fajl nije pronađen: " + filePath);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }


        public static async Task FakturaInfo()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite identifikator fakture (invoiceId): ");
            string invoiceId = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/sales-invoice?invoiceId={invoiceId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        string result = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Informacije o fakturi: ");
                        Console.WriteLine(result);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }



        public static async Task FakturaBrisanje()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite identifikatore faktura za brisanje (razdvojene zarezom, npr. 123,456,789): ");
            string ids = Console.ReadLine();

            string baseUrl = "https://efaktura.mfin.gov.rs/api/publicApi/sales-invoice";
            string jsonBody = $"[{ids}]";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);
                    HttpContent content = new StringContent(jsonBody, Encoding.UTF8, "application/json");

                    HttpResponseMessage response = await client.DeleteAsync(baseUrl + $"?body={jsonBody}");
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Fakture su uspešno obrisane!");
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }



        public static async Task FakturaPotpis()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite identifikator fakture (invoiceId): ");
            string invoiceId = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/sales-invoice/signature?invoiceId={invoiceId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        string result = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Potpis fakture je uspešno dobijen:");
                        Console.WriteLine(result);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task FakturaOtkazivanje()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite identifikator fakture (invoiceId): ");
            string invoiceId = Console.ReadLine();

            Console.Write("Unesite komentare za otkazivanje: ");
            string cancelComments = Console.ReadLine();

            string baseUrl = "https://efaktura.mfin.gov.rs/api/publicApi/sales-invoice/cancel";

            var requestBody = new StringContent(
                $"{{\"invoiceId\": {invoiceId}, \"cancelComments\": \"{cancelComments}\"}}",
                Encoding.UTF8,
                "application/json");

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.PostAsync(baseUrl, requestBody);
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Faktura je uspešno otkazana.");
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }


        public static async Task FakturaStorno()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite identifikator fakture (invoiceId): ");
            string invoiceId = Console.ReadLine();

            Console.Write("Unesite broj storna (stornoNumber): ");
            string stornoNumber = Console.ReadLine();

            Console.Write("Unesite komentar storna (stornoComment): ");
            string stornoComment = Console.ReadLine();

            string baseUrl = "https://efaktura.mfin.gov.rs/api/publicApi/sales-invoice/storno";

            var requestBody = new StringContent(
                $"{{\"invoiceId\": {invoiceId}, \"stornoNumber\": \"{stornoNumber}\", \"stornoComment\": \"{stornoComment}\"}}",
                Encoding.UTF8,
                "application/json");

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.PostAsync(baseUrl, requestBody);
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Storno fakturisanje je uspešno izvršeno.");
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }


        public static async Task NabavnaFakturaPreuzimanje()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite identifikator fakture (invoiceId): ");
            string invoiceId = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/purchase-invoice?invoiceId={invoiceId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        string result = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Informacije o nabavnoj fakturi su uspešno dobijene:");
                        Console.WriteLine(result);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }



        public static async Task FakturaProdajnaXml()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite identifikator fakture (invoiceId): ");
            string invoiceId = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/sales-invoice/xml?invoiceId={invoiceId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        // Pretpostavka da API vraća fajl direktno
                        var stream = await response.Content.ReadAsStreamAsync();
                        string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "invoice.xml");

                        using (var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write))
                        {
                            stream.CopyTo(fileStream);
                        }

                        Console.WriteLine($"Faktura je uspešno preuzeta i sačuvana na: {filePath}");
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }


        public static async Task PregledStatusaFakture()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite datum za pretragu (YYYY-MM-DD): ");
            string date = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/sales-invoice/changes?date={date}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.PostAsync(baseUrl, null); // Sending a POST request
                    if (response.IsSuccessStatusCode)
                    {
                        string result = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Rezultati pretrage promena statusa faktura:");
                        Console.WriteLine(result);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task ListaRazlogaPdvIzuzece()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            string baseUrl = "https://efaktura.mfin.gov.rs/api/publicApi/sales-invoice/getValueAddedTaxExemptionReasonList";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        string result = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Lista razloga za izuzeće od PDV-a:");
                        Console.WriteLine(result);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }


        public static async Task FakturaPoStatusuIDatumu()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite status fakture (npr. Approved, Cancelled): ");
            string status = Console.ReadLine();

            Console.Write("Unesite početni datum (YYYY-MM-DD): ");
            string dateFrom = Console.ReadLine();

            Console.Write("Unesite krajnji datum (YYYY-MM-DD): ");
            string dateTo = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/sales-invoice/ids?status={status}&dateFrom={dateFrom}&dateTo={dateTo}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.PostAsync(baseUrl, null); // Sending a POST request
                    if (response.IsSuccessStatusCode)
                    {
                        string result = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("ID-ovi faktura:");
                        Console.WriteLine(result);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }


        public static async Task FakturaDraftBrisanje()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite identifikator fakture (invoiceId): ");
            string invoiceId = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/sales-invoice/{invoiceId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.DeleteAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Faktura je uspešno obrisana.");
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }


        public static async Task FakturaNabavnaPoStatusuIDatumu()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite datum za pretragu (YYYY-MM-DD): ");
            string date = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/purchase-invoice/changes?date={date}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.PostAsync(baseUrl, null); // Sending a POST request
                    if (response.IsSuccessStatusCode)
                    {
                        string result = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Rezultati pretrage promena statusa nabavnih faktura:");
                        Console.WriteLine(result);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }


        public static async Task FakturaNabavnaXml()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite identifikator fakture (invoiceId): ");
            string invoiceId = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/purchase-invoice/xml?invoiceId={invoiceId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        // Pretpostavka da API vraća fajl direktno
                        var stream = await response.Content.ReadAsStreamAsync();
                        string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "purchaseInvoice.xml");

                        using (var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write))
                        {
                            stream.CopyTo(fileStream);
                        }

                        Console.WriteLine($"Nabavna faktura je uspešno preuzeta i sačuvana na: {filePath}");
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }


        public static async Task FakturaNabavnaPrihvatiOdbi()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite identifikator fakture (invoiceId): ");
            string invoiceId = Console.ReadLine();

            Console.Write("Prihvatate li fakturu? (true/false): ");
            bool accepted = bool.Parse(Console.ReadLine());

            Console.Write("Unesite komentar (opciono): ");
            string comment = Console.ReadLine();

            string baseUrl = "https://efaktura.mfin.gov.rs/api/publicApi/purchase-invoice/acceptRejectPurchaseInvoice";

            var requestBody = new StringContent(
                $"{{\"invoiceId\": {invoiceId}, \"accepted\": {accepted}, \"comment\": \"{comment}\"}}",
                Encoding.UTF8,
                "application/json");

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.PostAsync(baseUrl, requestBody);
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Operacija uspešna. Faktura je obradjena.");
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }



        public static async Task FakturaNabavnaPotpis()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite identifikator fakture (invoiceId): ");
            string invoiceId = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/purchase-invoice/signature?invoiceId={invoiceId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        string result = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Potpis nabavne fakture:");
                        Console.WriteLine(result);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task FakturaNabavnaIdPoStatusuIDatumu()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite status fakture (npr. Approved, Rejected): ");
            string status = Console.ReadLine();

            Console.Write("Unesite početni datum (YYYY-MM-DD): ");
            string dateFrom = Console.ReadLine();

            Console.Write("Unesite krajnji datum (YYYY-MM-DD): ");
            string dateTo = Console.ReadLine();

            string baseUrl = "https://efaktura.mfin.gov.rs/api/publicApi/purchase-invoice/ids";

            var requestBody = new StringContent(
                $"{{\"status\": \"{status}\", \"dateFrom\": \"{dateFrom}\", \"dateTo\": \"{dateTo}\"}}",
                Encoding.UTF8,
                "application/json");

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.PostAsync(baseUrl, requestBody);
                    if (response.IsSuccessStatusCode)
                    {
                        string result = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("ID-ovi nabavnih faktura:");
                        Console.WriteLine(result);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }


        public static async Task SubscribeToInvoiceStatusChanges()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            string baseUrl = "https://efaktura.mfin.gov.rs/api/publicApi/subscribe";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.PostAsync(baseUrl, null);
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Uspešno ste se pretplatili na obaveštenja o promenama statusa faktura za sutrašnji dan.");
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task RecordVATReverseCharge()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite identifikator nabavne fakture (purchaseInvoiceId): ");
            int invoiceId = int.Parse(Console.ReadLine());

            Console.Write("Unesite iznos PDV-a: ");
            decimal vatAmount = decimal.Parse(Console.ReadLine());

            string baseUrl = "https://efaktura.mfin.gov.rs/api/publicApi/purchase-invoice/vatReverseCharge";
            var requestBody = new StringContent(
                $"{{\"purchaseInvoiceId\": {invoiceId}, \"vatAmount\": {vatAmount}}}",
                Encoding.UTF8,
                "application/json");

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.PostAsync(baseUrl, requestBody);
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("PDV za nabavnu fakturu uspešno je evidentiran.");
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }


        public static async Task RecordGroupVATWithCorrection()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite ID grupe PDV-a (groupVatId): ");
            int groupVatId = int.Parse(Console.ReadLine());

            var requestBody = new StringContent(
                @"
                {
                  ""year"": 2024,
                  ""vatPeriod"": ""January"",
                  ""turnoverWithFee"": {
                    ""taxableAmount20"": 100000.00,
                    ""taxAmount20"": 20000.00,
                    ""totalAmount20"": 120000.00,
                    ""taxableAmount10"": 50000.00,
                    ""taxAmount10"": 5000.00,
                    ""totalAmount10"": 55000.00,
                    ""turnoverDescription10"": ""Prodaja opreme"",
                    ""turnoverDescription20"": ""Prodaja softvera""
                  },
                  ""turnoverWithoutFee"": {
                    ""taxableAmount20"": 80000.00,
                    ""taxAmount20"": 16000.00,
                    ""totalAmount20"": 96000.00,
                    ""taxableAmount10"": 40000.00,
                    ""taxAmount10"": 4000.00,
                    ""totalAmount10"": 44000.00,
                    ""turnoverDescription10"": ""Usluge"",
                    ""turnoverDescription20"": ""Održavanje""
                  },
                  ""futureTurnover"": {
                    ""taxableAmount20"": 60000.00,
                    ""taxAmount20"": 12000.00,
                    ""totalAmount20"": 72000.00,
                    ""taxableAmount10"": 30000.00,
                    ""taxAmount10"": 3000.00,
                    ""totalAmount10"": 33000.00,
                    ""turnoverDescription10"": ""Predprodaja"",
                    ""turnoverDescription20"": ""Postprodaja""
                  },
                  ""turnoverDate"": ""2024-05-04T19:55:51.134Z"",
                  ""vatReductionFromPreviousPeriodAmount"": 1000.00,
                  ""vatIncreaseFromPreviousPeriodAmount"": 2000.00,
                  ""calculationNumber"": ""Calc-001""
                }",
                Encoding.UTF8,
                "application/json");

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/vat-recording/group?groupVatId={groupVatId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.PostAsync(baseUrl, requestBody);
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Grupni PDV uspešno evidentiran sa mogućim korekcijama.");
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task FetchGroupVATRecords()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite datum od (yyyy-MM-dd): ");
            string dateFrom = Console.ReadLine();
            Console.Write("Unesite datum do (yyyy-MM-dd): ");
            string dateTo = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/vat-recording/group?dateFrom={dateFrom}&dateTo={dateTo}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        string result = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Evidencije PDV-a su uspešno dohvaćene:");
                        Console.WriteLine(result);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task CancelGroupVatRecordings()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite ID grupe PDV-a (groupVatId): ");
            int groupVatId = int.Parse(Console.ReadLine());

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/vat-recording/group/cancel/{groupVatId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.DeleteAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Sve verzije grupne evidencije PDV-a su uspešno otkazane.");
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }


        public static async Task GetGroupVatRecordById()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite ID grupe PDV-a (groupVatId): ");
            int groupVatId = int.Parse(Console.ReadLine());

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/vat-recording/group/{groupVatId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        string result = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Detalji grupe PDV-a:");
                        Console.WriteLine(result);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }


        public static async Task RecordIndividualVAT()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite ID individualnog PDV-a (individualVatId): ");
            int individualVatId = int.Parse(Console.ReadLine());

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/vat-recording/individual/{individualVatId}";

            var vatData = new
            {
                documentNumber = "string",
                turnoverDate = "2024-05-04T20:12:28.394Z",
                paymentDate = "2024-05-04T20:12:28.394Z",
                documentType = "Invoice",
                year = 9999,
                turnoverDescription = "string",
                turnoverAmount = 99999999999999.98,
                vatBaseAmount20 = 99999999999999.98,
                vatBaseAmount10 = 99999999999999.98,
                vatAmount = 99999999999999.98,
                vatAmount10 = 99999999999999.98,
                vatAmount20 = 99999999999999.98,
                totalAmount = 99999999999999.98,
                vatDeductionRight = "None",
                relatedDocuments = new[] { new { documentNumber = "string" } },
                documentDirection = "Inbound",
                relatedPartyIdentifier = "string",
                foreignDocument = true,
                turnoverDescription20 = "string",
                turnoverDescription10 = "string",
                vatPeriod = "January",
                internalInvoiceOption = "Turnover",
                calculationNumber = "string",
                basisForPrepayment = "string"
            };

            string jsonContent = JsonConvert.SerializeObject(vatData);
            StringContent content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.PostAsync(baseUrl, content);
                    if (response.IsSuccessStatusCode)
                    {
                        string result = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Uspešno evidentiran PDV:");
                        Console.WriteLine(result);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task GetIndividualVATRecords()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite početni datum (format: yyyy-MM-dd): ");
            string dateFrom = Console.ReadLine();

            Console.Write("Unesite krajnji datum (format: yyyy-MM-dd): ");
            string dateTo = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/vat-recording/individual?dateFrom={dateFrom}&dateTo={dateTo}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        string result = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Uspešno dohvaćeni PDV zapisi:");
                        Console.WriteLine(result);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }


        public static async Task CancelIndividualVATRecord()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite ID individualne PDV evidencije za otkazivanje: ");
            string individualVatId = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/vat-recording/individual/cancel/{individualVatId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.PostAsync(baseUrl, null);
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Individualna PDV evidencija je uspešno otkazana.");
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task GetIndividualVATRecord()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite ID individualne PDV evidencije za dohvatanje: ");
            string individualVatId = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/vat-recording/individual/{individualVatId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        string responseData = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Podaci o individualnoj PDV evidenciji:");
                        Console.WriteLine(responseData);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task GetFiscalBillDetails()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite broj fiskalnog računa za dohvatanje: ");
            string fiscalBillNumber = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/fiscal-bill/{fiscalBillNumber}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        string responseData = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Detalji fiskalnog računa:");
                        Console.WriteLine(responseData);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task GetFiscalBillForPurchase()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite broj fiskalnog računa za dohvatanje: ");
            string fiscalBillNumber = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/fiscalization/purchase/fiscal-bill/{fiscalBillNumber}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        string responseData = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Detalji fiskalnog računa za nabavku:");
                        Console.WriteLine(responseData);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task SearchInvoicesByStatusChange()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite datum (YYYY-MM-DD) za koji želite pretraživanje promene statusa faktura: ");
            string date = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/public-purchase-contractor-invoice/changes?date={date}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.PostAsync(baseUrl, null); // POST metoda sa praznim telom
                    if (response.IsSuccessStatusCode)
                    {
                        string responseData = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Rezultati pretrage:");
                        Console.WriteLine(responseData);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task DownloadPublicPurchaseInvoiceXML()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite ID fakture za preuzimanje XML: ");
            string invoiceId = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/public-purchase-contractor-invoice/xml?invoiceId={invoiceId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl); // GET metoda za preuzimanje XML
                    if (response.IsSuccessStatusCode)
                    {
                        string responseData = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("XML Fakture:");
                        Console.WriteLine(responseData);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task DownloadPublicPurchaseInvoice()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite ID fakture za preuzimanje: ");
            string invoiceId = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/public-purchase-contractor-invoice?invoiceId={invoiceId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl); // GET metoda za preuzimanje fakture
                    if (response.IsSuccessStatusCode)
                    {
                        string responseData = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Podaci o fakturi:");
                        Console.WriteLine(responseData);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task DownloadPublicPurchaseInvoiceSignature()
        {
            Console.Write("Unesite API ključ: ");
            string apiKey = Console.ReadLine();

            Console.Write("Unesite ID fakture za preuzimanje potpisa: ");
            string invoiceId = Console.ReadLine();

            string baseUrl = $"https://efaktura.mfin.gov.rs/api/publicApi/public-purchase-contractor-invoice/signature?invoiceId={invoiceId}";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                    HttpResponseMessage response = await client.GetAsync(baseUrl); // GET metoda za preuzimanje potpisa fakture
                    if (response.IsSuccessStatusCode)
                    {
                        string responseData = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Potpis fakture:");
                        Console.WriteLine(responseData);
                    }
                    else
                    {
                        Console.WriteLine("Došlo je do greške: " + response.StatusCode);
                        Console.WriteLine("Poruka greške: " + await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Došlo je do izuzetka: " + ex.Message);
            }
        }

        public static async Task FetchInvoiceIDs()
        {
            string apiKey = "Vaš API ključ";
            string status = "New"; // Ovo može biti New, Seen, ReNotified, Approved, Rejected, Storno
            string dateFrom = "2023-01-01"; // Format datuma YYYY-MM-DD
            string dateTo = "2023-12-31"; // Format datuma YYYY-MM-DD

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                string url = $"https://efaktura.mfin.gov.rs/api/publicApi/public-purchase-contractor-invoice/ids?status={status}&dateFrom={dateFrom}&dateTo={dateTo}";

                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("ID-ovi fakture:");
                    Console.WriteLine(result);
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri preuzimanju ID-ova fakture:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }

        public static async Task FetchCIRTickets()
        {
            string apiKey = "Vaš API ključ";
            string cirInvoiceId = "Vaš CIR Invoice ID";
            bool onlyActiveTickets = true; // true za samo aktivne tikete, false za sve tikete

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                string url = $"https://efaktura.mfin.gov.rs/api/publicApi/cir-tickets/{cirInvoiceId}/{onlyActiveTickets}";

                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("Tiketi:");
                    Console.WriteLine(result);
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri preuzimanju tiketa:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }

        public static async Task FindCIRTickets()
        {
            string apiKey = "Vaš API ključ";
            string url = "https://efaktura.mfin.gov.rs/api/publicApi/cir-tickets/find";

            var requestData = new
            {
                sortItems = new[]
                {
                    new { sortColumn = "CirId", sortDirection = "Asc" }
                },
                pagingOptions = new { pageIndex = 0, pageSize = 10 },
                restrictions = new[]
                {
                    new { field = "CirId", values = new string[] { "specific-cir-id" } }
                }
            };

            string jsonRequest = JsonConvert.SerializeObject(requestData);

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);
                var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(url, content);
                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("Rezultati:");
                    Console.WriteLine(result);
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri pretrazi tiketa:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }

        public static async Task CreateCIRTicket()
        {
            string apiKey = "Vaš API ključ";
            string url = "https://efaktura.mfin.gov.rs/api/publicApi/cir-tickets/addCirTicket";

            var requestData = new
            {
                cirInvoiceId = "specifični-cir-invoice-id",
                data = "string",
                amount = "string",
                userComment = "Vaš komentar",
                resourceType = "Invoice",
                cirTicketCategory = "Information"
            };

            string jsonRequest = JsonConvert.SerializeObject(requestData);

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);
                var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(url, content);
                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("Rezultati:");
                    Console.WriteLine(result);
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri kreiranju tiketa:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }

        public static async Task GetCirTicketHistory()
        {
            string apiKey = "Vaš API ključ";
            string cirTicketId = "12345"; // Promenite ovo prema vašem ID-u tiketa
            string url = $"https://efaktura.mfin.gov.rs/api/publicApi/cir-tickets/getCirTicketHistory/{cirTicketId}";

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("Rezultati:");
                    Console.WriteLine(result);
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri pribavljanju istorije tiketa:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }

        public static async Task GetSalesInvoiceAssignmentHistory()
        {
            string apiKey = "Vaš API ključ";
            string cirInvoiceId = "12345"; // Promenite ovo prema vašem ID-u fakture
            string url = $"https://efaktura.mfin.gov.rs/api/publicApi/sales-cir-invoice/getSalesInvoiceAssignmentHistory/{cirInvoiceId}";

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("Rezultati:");
                    Console.WriteLine(result);
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri pribavljanju istorije dodeljivanja faktura:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }

        public static async Task GetInvoicePaymentsAndHistory()
        {
            string apiKey = "Vaš API ključ";
            string cirInvoiceId = "12345"; // Promenite ovo prema vašem ID-u fakture
            string url = $"https://efaktura.mfin.gov.rs/api/publicApi/sales-cir-invoice/getInvoicePaymentsAndHistory/{cirInvoiceId}";

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("Rezultati:");
                    Console.WriteLine(result);
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri pribavljanju informacija o uplatama i istoriji uplata:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }

        public static async Task DownloadInvoiceAsFileStream()
        {
            string apiKey = "Vaš API ključ";
            string cirInvoiceId = "12345"; // Promenite ovo prema vašem ID-u fakture
            string url = $"https://efaktura.mfin.gov.rs/api/publicApi/purchase-invoice/ubl/{cirInvoiceId}";

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    using (var stream = await response.Content.ReadAsStreamAsync())
                    {
                        using (var fileStream = new FileStream($"invoice_{cirInvoiceId}.xml", FileMode.Create, FileAccess.Write))
                        {
                            stream.CopyTo(fileStream);
                        }
                    }
                    Console.WriteLine("Faktura je uspešno preuzeta i sačuvana.");
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri preuzimanju fakture:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }

        public static async Task AssignCirInvoice()
        {
            string apiKey = "Vaš API ključ";
            string cirInvoiceId = "12345"; // Promenite ovo prema vašem ID-u fakture
            string assignerPartyJBKJS = "Vaš JBKJS"; // JBKJS broj stranke koja dodeljuje
            string assignationContractNumber = "1234567890"; // Broj ugovora o dodeli

            string url = $"https://efaktura.mfin.gov.rs/api/publicApi/purchase-invoice/{cirInvoiceId}/assign?AssignerPartyJBKJS={assignerPartyJBKJS}&AssignationContractNumber={assignationContractNumber}";

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                var response = await client.PostAsync(url, null); // POST poziv bez tela zahteva
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Dodela fakture je uspešna.");
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri dodeli fakture:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }

        public static async Task CancelAssignCirInvoice()
        {
            string apiKey = "Vaš API ključ";
            string cirInvoiceId = "12345"; // Promenite ovo prema vašem ID-u fakture

            string url = $"https://efaktura.mfin.gov.rs/api/publicApi/purchase-invoice/{cirInvoiceId}/cancelassign";

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                var response = await client.GetAsync(url); // GET poziv
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Otkazivanje dodele fakture je uspešno.");
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri otkazivanju dodele fakture:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }

        public static async Task AcceptRejectCirInvoice()
        {
            string apiKey = "Vaš API ključ";
            string cirInvoiceId = "12345"; // Promenite ovo prema vašem ID-u fakture
            bool accepted = true; // True za prihvatanje, false za odbijanje
            string comment = "Vaš komentar"; // Opcioni komentar

            string url = "https://efaktura.mfin.gov.rs/api/publicApi/purchase-invoice/acceptRejectPurchaseInvoiceByCirInvoiceId";

            var invoiceDecision = new
            {
                cirInvoiceId = cirInvoiceId,
                accepted = accepted,
                comment = comment
            };

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                var response = await client.PostAsJsonAsync(url, invoiceDecision); // POST poziv
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Akcija na fakturi je uspešno izvršena.");
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri izvršavanju akcije na fakturi:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }

        public static async Task GetPurchaseInvoiceAssignmentHistory()
        {
            string apiKey = "Vaš API ključ";
            string cirInvoiceId = "12345"; // Promenite ovo prema vašem CIR ID fakture

            string url = $"https://efaktura.mfin.gov.rs/api/publicApi/purchase-cir-invoice/getPurchaseInvoiceAssignmentHistory/{cirInvoiceId}";

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                var response = await client.GetAsync(url); // GET poziv
                if (response.IsSuccessStatusCode)
                {
                    string content = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("Odgovor od servera:");
                    Console.WriteLine(content);
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri dohvatanju istorije dodeljivanja fakture:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }

        public static async Task GetInvoicePaymentsAndHistoryByCIRId()
        {
            string apiKey = "Vaš API ključ";
            string cirInvoiceId = "12345";  // Zamijenite sa vašim CIR invoice ID

            string url = "https://efaktura.mfin.gov.rs/api/publicApi/purchase-cir-invoice/getInvoicePaymentsAndHistory/" + cirInvoiceId;

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Uspješno dohvaćeni podaci o plaćanjima i istoriji plaćanja:");
                    string content = await response.Content.ReadAsStringAsync();
                    Console.WriteLine(content);
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri dohvatanju podataka:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }

        public static async Task UpdateCompany()
        {
            string apiKey = "Vaš API ključ"; // Zamenite sa vašim stvarnim API ključem
            string url = "https://efaktura.mfin.gov.rs/api/publicApi/company/update-company";

            var companyData = new
            {
                CompanyId = "12345", // Zamenite sa stvarnim ID kompanije
                Name = "Nova Ime Kompanije", // Novo ime kompanije
                Address = "Nova Adresa Kompanije", // Nova adresa
                City = "Novi Grad", // Novi grad
                PostalCode = "11000", // Novi poštanski broj
                Country = "Srbija" // Zemlja
                                   // Dodajte dodatne parametre prema potrebi
            };

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                var response = await client.PutAsJsonAsync(url, companyData); // PUT poziv
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Informacije o kompaniji su uspešno ažurirane.");
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri ažuriranju informacija o kompaniji:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }


        public static async Task CheckIfCompanyRegisteredOnEFaktura()
        {
            string apiKey = "Vaš API ključ";
            string url = "https://efaktura.mfin.gov.rs/api/publicApi/Company/CheckIfCompanyRegisteredOnEFaktura";

            var companyDetails = new
            {
                registrationNumber = "broj registracije",
                jbkbjs = "JBKBJS",
                vatNumber = "PIB"
            };

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("ApiKey", apiKey);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, companyDetails);
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Provera statusa naloga je uspešna.");
                    string result = await response.Content.ReadAsStringAsync();
                    Console.WriteLine(result);
                }
                else
                {
                    Console.WriteLine("Došlo je do greške pri proveri statusa naloga:");
                    Console.WriteLine(response.StatusCode);
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                }
            }
        }


    }
}

